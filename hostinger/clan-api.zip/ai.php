<?php
// POST multipart: kind=clan|profile|loadout, image=<screenshot>
//   clan    → clan log / member list (admin)
//   profile → player profile: name + UID (admin)
//   loadout → gunsmith screenshot (clan password)
// → { ok, kind, result, usage, model }
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/roster.php';
require __DIR__ . '/lib/images.php';
require __DIR__ . '/lib/claude.php';
cors(['POST']);
@set_time_limit(180);

$kind = (string) ($_POST['kind'] ?? '');
$needs = ['clan' => 'admin', 'profile' => 'admin', 'loadout' => 'clan'][$kind] ?? null;
if ($needs === null) throw new ApiError(400, 'kind must be clan, profile or loadout');
$role = require_role($needs);

if (!sdk_available()) throw new ApiError(503, 'The Claude SDK (vendor folder) is missing — re-upload clan-api.zip');
if (!ai_configured()) throw new ApiError(503, 'The Claude API key is not set on the server yet (secrets.php)');

$img = uploaded_image('image');

$perIp = (array) cfg('ai_hourly_per_ip', []);
if (!rate_take('ai-ip-' . ip_tag() . "-$role", (int) ($perIp[$role] ?? 20), 3600)) {
  throw new ApiError(429, 'Too many screenshots from this device in the last hour — try again later');
}
if (!rate_take('ai-24h', (int) cfg('ai_daily_limit', 150), 86400)) {
  throw new ApiError(429, 'The clan has used today\'s screenshot-reading allowance — try again tomorrow');
}

[$bytes, $mime] = ai_prepare_image($img['path'], $img['mime']);
$brief = $kind === 'loadout' ? [] : roster_brief(roster_load());
$out = ai_extract($kind, $bytes, $mime, $brief);
send_json(200, ['ok' => true, 'kind' => $kind] + ['result' => $out['data'], 'usage' => $out['usage'], 'model' => $out['model']]);
